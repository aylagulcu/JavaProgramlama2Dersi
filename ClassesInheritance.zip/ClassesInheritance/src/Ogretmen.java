

/*
 *
 * Ogretmen class' ı Katilimci class' ının bütün özelliklerini, metodlarını alıyor (inheritance)
 */

public class Ogretmen extends Katilimci{
    
    // Bu class için geçerli özellikler (properties):
    public String konusmaKonusu;
    public int ogrenciSayisi;
    
}
