/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Furkan
 */
public class Kisi {
   private String isim,bolum,cinsiyet;
   private  int id,dogum,şifre;
    public static int sayac=0;
  public Kisi(){
      sayac++;
    
}
  public String get_isim(){
    return isim;
}
  public void set_isim(String s){
      isim=s;
      }
  public String get_bolum(){
      return bolum;
  }
  public void set_bolum(String t){
      bolum=t;
  }
  public String get_cinsiyet(){
      return cinsiyet;
  }
  public void set_cinsiyet(String c){
      cinsiyet=c;
  }
  public int get_id(){
    return id;
}
  public void set_id(int z){
      id=z;
  }
  public int get_dogum(){
      return dogum;
  }
  public void set_dogum(int d){
      dogum=d;
  }
  public int get_şifre(){
      return şifre;
  }
  public void set_şifre(int ş){
      şifre=ş;
      
  }
}
